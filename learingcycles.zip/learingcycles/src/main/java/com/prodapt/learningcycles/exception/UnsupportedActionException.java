package com.prodapt.learningcycles.exception;

public class UnsupportedActionException extends Exception {

	private static final long serialVersionUID = 6166534645931469855L;
	public UnsupportedActionException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
